RACE LEGENDS SİTESİ — KURULUM

İÇERİK
- index.html: web sitesi giriş sayfası
- race/index.html: Race Legends oyunu
- Race_Legends_PC.zip: oyunun indirilebilir ZIP arşivi

YEREL TEST
1. ZIP dosyasını tamamen çıkar.
2. index.html dosyasını tarayıcıda aç.
3. İnternet bağlantısı gerekebilir; oyun Three.js gibi harici kütüphaneler kullanıyorsa CDN'e erişim gerekir.

ÜCRETSİZ YAYIN (GitHub Pages)
1. github.com üzerinde hesap aç/giriş yap.
2. New repository ile yeni depo oluştur (ör. race-legends-site).
3. Bu klasörün içindeki DOSYALARI ve race klasörünü depoya yükle; zip dosyasını da yükle.
4. Repository Settings > Pages bölümünü aç.
5. Build and deployment altında Deploy from a branch seç; branch olarak main, folder olarak /(root) seçip Save'e bas.
6. GitHub Pages yayınladığında sana https://KULLANICIADIN.github.io/race-legends-site/ benzeri ücretsiz bir adres verir.

NOTLAR
- Bu dosyalar siteyi hazırlamaya hazırlar; site henüz internette yayınlanmış değildir.
- Gerçek bir web adresi oluşturmak için dosyaları bir barındırma hizmetine yüklemek gerekir.
- Oyunu herkese açık paylaşmadan önce oyun dosyalarını test et ve lisanslarını kontrol et.
